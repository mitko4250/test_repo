"use client";

import { useState } from "react";
import { Plus, Minus, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [count, setCount] = useState(0);

  const increment = () => setCount(count + 1);
  const decrement = () => setCount(count - 1);
  const reset = () => setCount(0);

  return (
    <main className="min-h-screen w-full flex items-center justify-center p-4 bg-gradient-to-br from-blue-400 via-blue-500 to-blue-600 relative overflow-hidden">
      {/* Animated background blobs */}
      <div className="absolute top-20 left-20 w-72 h-72 bg-blue-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
      <div className="absolute top-40 right-20 w-72 h-72 bg-cyan-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
      <div className="absolute -bottom-8 left-1/2 w-72 h-72 bg-indigo-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>

      {/* Glassmorphism Counter Card */}
      <div className="relative z-10 w-full max-w-md">
        <div className="backdrop-blur-xl bg-white/20 rounded-3xl p-8 sm:p-12 shadow-2xl border border-white/30 hover:bg-white/25 transition-all duration-300">
          {/* Counter Display */}
          <div className="text-center mb-8">
            <div className="inline-block backdrop-blur-lg bg-white/30 rounded-2xl px-8 py-6 border border-white/40 shadow-lg">
              <p className="text-sm font-medium text-white/80 mb-2 tracking-wider uppercase">Counter</p>
              <p className="text-7xl sm:text-8xl font-bold text-white drop-shadow-lg tabular-nums">
                {count}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col gap-4">
            {/* Increment Button */}
            <button
              onClick={increment}
              className="group relative backdrop-blur-lg bg-blue-600/40 hover:bg-blue-600/60 text-white font-semibold py-4 px-6 rounded-xl border border-white/30 shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl active:scale-95 flex items-center justify-center gap-3"
            >
              <Plus className="w-6 h-6 transition-transform group-hover:rotate-90 duration-300" />
              <span className="text-lg">Increment</span>
            </button>

            {/* Decrement Button */}
            <button
              onClick={decrement}
              className="group relative backdrop-blur-lg bg-blue-600/40 hover:bg-blue-600/60 text-white font-semibold py-4 px-6 rounded-xl border border-white/30 shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl active:scale-95 flex items-center justify-center gap-3"
            >
              <Minus className="w-6 h-6 transition-transform group-hover:rotate-180 duration-300" />
              <span className="text-lg">Decrement</span>
            </button>

            {/* Reset Button */}
            <button
              onClick={reset}
              className="group relative backdrop-blur-lg bg-white/20 hover:bg-white/30 text-white font-medium py-3 px-6 rounded-xl border border-white/30 shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl active:scale-95 flex items-center justify-center gap-3 mt-2"
            >
              <RotateCcw className="w-5 h-5 transition-transform group-hover:rotate-180 duration-500" />
              <span>Reset</span>
            </button>
          </div>

          {/* Stats */}
          <div className="mt-8 pt-6 border-t border-white/20">
            <div className="grid grid-cols-2 gap-4 text-center">
              <div className="backdrop-blur-md bg-white/10 rounded-xl p-3 border border-white/20">
                <p className="text-xs text-white/70 uppercase tracking-wide mb-1">Status</p>
                <p className="text-sm font-semibold text-white">
                  {count === 0 ? "Zero" : count > 0 ? "Positive" : "Negative"}
                </p>
              </div>
              <div className="backdrop-blur-md bg-white/10 rounded-xl p-3 border border-white/20">
                <p className="text-xs text-white/70 uppercase tracking-wide mb-1">Absolute</p>
                <p className="text-sm font-semibold text-white">{Math.abs(count)}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
